// Project Identifier: 1761414855B69983BD8035097EFBD312EB0527F0
//  LocationType.hpp
//  project4
//
//  Created by Michael Gertler on 4/6/20.
//  Copyright © 2020 Michael Gertler. All rights reserved.
//

#ifndef LocationType_h
#define LocationType_h

struct Vertex {
    int x;
    int y;
    char location;
};

#endif /* LocationType_h */
